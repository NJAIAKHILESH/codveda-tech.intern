#include <stdio.h>
#include <stdlib.h>

// Stack Node
struct StackNode {
    int data;
    struct StackNode* next;
};

struct StackNode* top = NULL;

// Push operation
void push(int value) {
    struct StackNode* newNode = (struct StackNode*)malloc(sizeof(struct StackNode));
    newNode->data = value;
    newNode->next = top;
    top = newNode;
}

// Pop operation
void pop() {
    if (top == NULL) {
        printf("Stack is empty.\n");
        return;
    }
    struct StackNode* temp = top;
    top = top->next;
    printf("Popped: %d\n", temp->data);
    free(temp);
}

// Display stack
void displayStack() {
    struct StackNode* current = top;
    printf("Stack: ");
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}
// Queue Node
struct QueueNode {
    int data;
    struct QueueNode* next;
};

struct QueueNode* front = NULL;
struct QueueNode* rear = NULL;

// Enqueue operation
void enqueue(int value) {
    struct QueueNode* newNode = (struct QueueNode*)malloc(sizeof(struct QueueNode));
    newNode->data = value;
    newNode->next = NULL;

    if (rear == NULL) {
        front = rear = newNode;
    } else {
        rear->next = newNode;
        rear = newNode;
    }
}

// Dequeue operation
void dequeue() {
    if (front == NULL) {
        printf("Queue is empty.\n");
        return;
    }
    struct QueueNode* temp = front;
    front = front->next;
    if (front == NULL)
        rear = NULL;
    printf("Dequeued: %d\n", temp->data);
    free(temp);
}

// Display queue
void displayQueue() {
    struct QueueNode* current = front;
    printf("Queue: ");
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}
int main() {
    int choice, value;

    while (1) {
        printf("\nChoose:\n1. Push (Stack)\n2. Pop (Stack)\n3. Display Stack\n");
        printf("4. Enqueue (Queue)\n5. Dequeue (Queue)\n6. Display Queue\n7. Exit\n");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to push: ");
                scanf("%d", &value);
                push(value);
                break;
            case 2:
                pop();
                break;
            case 3:
                displayStack();
                break;
            case 4:
                printf("Enter value to enqueue: ");
                scanf("%d", &value);
                enqueue(value);
                break;
            case 5:
                dequeue();
                break;
            case 6:
                displayQueue();
                break;
            case 7:
                exit(0);
            default:
                printf("Invalid choice.\n");
        }
    }

    return 0;
}