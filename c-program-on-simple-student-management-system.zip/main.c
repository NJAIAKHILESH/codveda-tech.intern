#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX_STUDENTS 100
struct student
{
    char name[50];
    int id;
    float grade;
};
struct student students[MAX_STUDENTS];
int studentcount=0;
void savetofile()
{
    FILE *file=fopen("students.dat","wb");
    if(!file)
    {
        printf("error opening file!\n");
        return;
    }
    fwrite(students, sizeof(struct student),studentcount,file);
    fclose(file);
}
void loadfromfile()
{
    FILE*file=fopen("students.dat","rb");
    if(!file)
    {
        return;
    }
    studentcount=fread(students, sizeof(struct student), MAX_STUDENTS, file);
    fclose(file);
}
void addstudent()
{
    if(studentcount >>= MAX_STUDENTS)
    {
        printf("cannot add more students!\n");
        return;
    }
    printf("enter name!\n");
    getchar();
    fgets(students[studentcount].name,50,stdin);
    students[studentcount].name[strcspn(students[studentcount].name,"\n")]=0;
    printf("enter ID:!\n");
    scanf("%d",&students[studentcount].id);
    printf("enter grade:!\n");
    scanf("%f",&students[studentcount].grade);
    studentcount++;
    savetofile();
    printf("student added successfully!\n");
}
void displaystudents()
{
    if (studentcount==0)
    {
        printf("no students found!\n");
        return;
    }
    for(int i=0;i<studentcount;i++)
    {
        printf("name:%s| ID:%d| Grade:%.2f\n", students[i].name, students[i].id,students[i].grade);
    }
}
void deletestudent()
{
    int id, found=0;
    printf("enter student ID to delete!\n");
    scanf("%d",&id);
    for(int i=0;i<studentcount;i++)
    {
        if(students[i].id==id)
        {
            for (int j=i;j<studentcount-1;j++)
            {
                students[j]=students[j+1];
            }
            studentcount--;
            savetofile();
            printf("student deleted successfully!\n");
            found=1;
            break;
        }
    }
    if(!found)
    {
        printf("student not found!\n");
    }
}
void updatestudent()
{
    int id,found=0;
    printf("enter student id to update!\n");
    scanf("%d",&id);
    for(int i=0;i<studentcount;i++)
    {
        if(students[i].id==id)
        {
            printf("enter new name!\n");
            getchar();
            fgets(students[i].name,50,stdin);
            students[i].name[strcspn(students[i].name,"\n")]=0;
            printf("enter new grade!\n");
            scanf("%f",&students[i].grade);
            savetofile();
            printf("student updated successfully!\n");
            found=1;
            break;
        }
    }
    if (!found)
    {
        printf("student not found!\n");
    }
}
int main()
{
    loadfromfile();
    int choice;
    do
    {
        printf("\nstudent management system\n");
        printf("1. add student\n2. display students\n3. update student\n4. delete student\n5. exit\n");
        printf("enter your choice\n");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:addstudent(); break;
            case 2:displaystudents(); break;
            case 3:updatestudent(); break;
            case 4:deletestudent(); break;
            case 5:printf("existing...\n"); break;
            default: printf("invalid choice! try again.\n");
        }
    }
    while(choice !=5);
    return 0;
}