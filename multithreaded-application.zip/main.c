#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define SIZE 5 // Buffer size

int buffer[SIZE];
int count = 0; // Number of items in buffer

pthread_mutex_t mutex;
pthread_cond_t notFull;
pthread_cond_t notEmpty;

// Producer function
void* producer(void* arg) {
    int item = 0;
    while (1) {
        item++; // Produce an item

        pthread_mutex_lock(&mutex);
        while (count == SIZE) {
            // Buffer full, wait
            pthread_cond_wait(&notFull, &mutex);
        }

        buffer[count] = item;
        count++;
        printf("Produced: %d\n", item);

        pthread_cond_signal(&notEmpty); // Signal consumer
        pthread_mutex_unlock(&mutex);

        sleep(1); // Simulate delay
    }
    return NULL;
}

// Consumer function
void* consumer(void* arg) {
    int item;
    while (1) {
        pthread_mutex_lock(&mutex);
        while (count == 0) {
            // Buffer empty, wait
            pthread_cond_wait(&notEmpty, &mutex);
        }

        item = buffer[count - 1];
        count--;
        printf("Consumed: %d\n", item);

        pthread_cond_signal(&notFull); // Signal producer
        pthread_mutex_unlock(&mutex);

        sleep(2); // Simulate delay
    }
    return NULL;
}

int main() {
    pthread_t prodThread, consThread;

    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&notFull, NULL);
    pthread_cond_init(&notEmpty, NULL);

    pthread_create(&prodThread, NULL, producer, NULL);
    pthread_create(&consThread, NULL, consumer, NULL);

    pthread_join(prodThread, NULL);
    pthread_join(consThread, NULL);

    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&notFull);
    pthread_cond_destroy(&notEmpty);

    return 0;
}