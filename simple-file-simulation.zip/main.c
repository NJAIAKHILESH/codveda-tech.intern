#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Max filename length
#define MAX_NAME 100

// Function to create a file
void createFile() {
    char filename[MAX_NAME];
    char content[500];

    printf("Enter file name to create: ");
    scanf("%s", filename);

    FILE *fp = fopen(filename, "w");
    if (fp == NULL) {
        printf("Error creating file.\n");
        return;
    }

    printf("Enter content to write in the file:\n");
    getchar(); // To consume leftover newline
    fgets(content, sizeof(content), stdin);

    fputs(content, fp);
    fclose(fp);
    printf("File '%s' created successfully.\n", filename);
}

// Function to read a file
void readFile() {
    char filename[MAX_NAME];
    char ch;

    printf("Enter file name to read: ");
    scanf("%s", filename);

    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("File not found or cannot be opened.\n");
        return;
    }

    printf("Contents of '%s':\n", filename);
    while ((ch = fgetc(fp)) != EOF) {
        putchar(ch);
    }

    fclose(fp);
}

// Function to delete a file
void deleteFile() {
    char filename[MAX_NAME];

    printf("Enter file name to delete: ");
    scanf("%s", filename);

    int status = remove(filename);
    if (status == 0)
        printf("File '%s' deleted successfully.\n", filename);
    else
        printf("Unable to delete file. File may not exist.\n");
}

int main() {
    int choice;

    while (1) {
        printf("\nSimple File System Menu:\n");
        printf("1. Create File\n");
        printf("2. Read File\n");
        printf("3. Delete File\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                createFile();
                break;
            case 2:
                readFile();
                break;
            case 3:
                deleteFile();
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}