#include <stdio.h>

// Bubble Sort - Time Complexity: O(n^2)
void bubbleSort(int arr[], int n) {
    for(int i = 0; i < n-1; i++) {
        for(int j = 0; j < n-i-1; j++) {
            if(arr[j] > arr[j+1]) {
                // Swap
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}

// Insertion Sort - Time Complexity: O(n^2)
void insertionSort(int arr[], int n) {
    for(int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while(j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

// Linear Search - Time Complexity: O(n)
int linearSearch(int arr[], int n, int target) {
    for(int i = 0; i < n; i++) {
        if(arr[i] == target)
            return i;
    }
    return -1;
}

// Binary Search - Time Complexity: O(log n)
// Note: Array must be sorted
int binarySearch(int arr[], int low, int high, int target) {
    while(low <= high) {
        int mid = (low + high) / 2;
        if(arr[mid] == target)
            return mid;
        else if(arr[mid] < target)
            low = mid + 1;
        else
            high = mid - 1;
    }
    return -1;
}

void printArray(int arr[], int n) {
    for(int i = 0; i < n; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

int main() {
    int n, choice, target;

    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);
    int arr[n];

    printf("Enter %d elements:\n", n);
    for(int i = 0; i < n; i++)
        scanf("%d", &arr[i]);

    printf("\nChoose sorting algorithm:\n1. Bubble Sort\n2. Insertion Sort\n");
    scanf("%d", &choice);
    
    if(choice == 1) {
        bubbleSort(arr, n);
        printf("Array after Bubble Sort:\n");
    } else {
        insertionSort(arr, n);
        printf("Array after Insertion Sort:\n");
    }

    printArray(arr, n);

    printf("\nEnter element to search: ");
    scanf("%d", &target);

    printf("Choose search method:\n1. Linear Search\n2. Binary Search (on sorted array)\n");
    scanf("%d", &choice);

    int result;
    if(choice == 1)
        result = linearSearch(arr, n, target);
    else
        result = binarySearch(arr, 0, n-1, target);

    if(result != -1)
        printf("Element found at index %d\n", result);
    else
        printf("Element not found\n");

    return 0;
}