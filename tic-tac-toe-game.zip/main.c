#include <stdio.h>

char board[3][3]; // 3x3 board

// Initialize the board with empty spaces
void initializeBoard() {
    for(int i = 0; i < 3; i++)
        for(int j = 0; j < 3; j++)
            board[i][j] = ' ';
}

// Display the game board
void displayBoard() {
    printf("\n");
    printf(" %c | %c | %c \n", board[0][0], board[0][1], board[0][2]);
    printf("---|---|---\n");
    printf(" %c | %c | %c \n", board[1][0], board[1][1], board[1][2]);
    printf("---|---|---\n");
    printf(" %c | %c | %c \n", board[2][0], board[2][1], board[2][2]);
    printf("\n");
}

// Check if a player has won
int checkWin(char mark) {
    // Rows and Columns
    for(int i = 0; i < 3; i++) {
        if((board[i][0] == mark && board[i][1] == mark && board[i][2] == mark) ||
           (board[0][i] == mark && board[1][i] == mark && board[2][i] == mark))
            return 1;
    }
    // Diagonals
    if((board[0][0] == mark && board[1][1] == mark && board[2][2] == mark) ||
       (board[0][2] == mark && board[1][1] == mark && board[2][0] == mark))
        return 1;

    return 0;
}

// Check for draw
int isDraw() {
    for(int i = 0; i < 3; i++)
        for(int j = 0; j < 3; j++)
            if(board[i][j] == ' ')
                return 0;
    return 1;
}

int main() {
    int row, col, player = 1;
    char mark;

    initializeBoard();

    while(1) {
        displayBoard();
        mark = (player == 1) ? 'X' : 'O';

        printf("Player %d (%c), enter row and column (0-2): ", player, mark);
        scanf("%d %d", &row, &col);

        if(row < 0 || row > 2 || col < 0 || col > 2 || board[row][col] != ' ') {
            printf("Invalid move. Try again.\n");
            continue;
        }

        board[row][col] = mark;

        if(checkWin(mark)) {
            displayBoard();
            printf("Player %d (%c) wins!\n", player, mark);
            break;
        }

        if(isDraw()) {
            displayBoard();
            printf("It's a draw!\n");
            break;
        }

        player = (player == 1) ? 2 : 1; // Switch player
    }

    return 0;
}